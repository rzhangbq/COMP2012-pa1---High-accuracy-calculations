//submit this file only
#include "decimal.h"
using namespace std;
//add your code below
//see FAQ for what you can/cannot do 